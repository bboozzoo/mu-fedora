#!/bin/sh
echo "please use 'autoreconf -i'"
